while true; do
  curl https://loadexample-xxxxx.cfapps.us10.hana.ondemand.com/rest/createload/load/3 > /dev/null &2>1 &
  sleep 1
done
