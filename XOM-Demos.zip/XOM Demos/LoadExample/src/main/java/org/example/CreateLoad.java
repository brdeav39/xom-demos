package org.example;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

@Path("createload")
public class CreateLoad {

	@GET
	@Path("/load")
	@Produces("text/plain")
	public Response createLotsOfLoad() {
		return createLotsOfLoad(1);
	}

	@GET
	@Path("/load/{multiplier}")
	@Produces("text/plain")
	public Response createLotsOfLoad(@PathParam("multiplier") Integer mult) {

		long start = System.currentTimeMillis();
		String outString = "";

		for (int i = 1; i <= 100 * mult; i++) {
			for (int j = 1; j <= 10000; j++) {
				double foo = j * 20.1 / i + start;
				outString = "Running Loop " + i + ":" + j + " value is : " + foo;

				if (i % 10 == 0 && j == 10000)
					System.out.println(outString);
			}

		}

		long end = System.currentTimeMillis();

		// return Response.status(200).entity("Created load using multiplier " +
		// mult + ", taking "
		// + NumberFormat.getIntegerInstance().format(end - start) + "
		// ms.").build();
		return Response.status(200).entity("" + (end - start)).build();
	}

}
